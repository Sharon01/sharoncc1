# Neighbourhood Map of India
===============================

This is an app featuring some of the states of India.


## Run

1) Locally
----Clone it via github https://github.com/Sharon01/sharoncc1
----Run the file from the repository.

Or 

2) 
----Download the **Neighbourhood map** folder.
----Unzip the file and extract all the contects.
----Open the **Neighbourhood map** folder.
----Right click on **index.html** file and open with Google Chrome.
----Start using the app.


## How to use the app:

--Open the app.
--You can click on any markers to get informations about a particular state.
--You can also open the markers by clicking on the list items.
--The search box is served as an input to search places from all of the listed items. 

